import KingStorePage from '@/components/king-store/king-store-page';

export default function Home() {
  return <KingStorePage />;
}
