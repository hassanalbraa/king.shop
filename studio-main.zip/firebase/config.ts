export const firebaseConfig = {
  "projectId": "studio-268985317-a9f66",
  "appId": "1:2527322905:web:1bf2de0afff05dac8d9b88",
  "apiKey": "AIzaSyAUyev7HRCYvZl8cL4Q-wc-2e291v6zup8",
  "authDomain": "studio-268985317-a9f66.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "2527322905"
};
